// TODO more tests

describe('MultiCheck', () => {
  describe('initialize', () => {
    it('renders the label if label provided', () => {
      // TODO
    });
  });
});
