import './MultiCheck.css';

import React from 'react';

export type Option = {
  label: string,
  value: string
}

/**
 * Notice:
 * 1. There should be a special `Select All` option with checkbox to control all passing options
 * 2. If columns > 1, the options should be placed from top to bottom in each column
 *
 * @param {string} label - the label text of this component
 * @param {Option[]} options - options
 * @param {string[]} values - default checked option values
 * @param {number} columns - default value is 1
 * @param {Function} onChange - when checked options are changed,
 *                             they should be passed to outside
 */
interface Props {
  label?: string;
  options: Option[];
  columns?: number;
  values: string[];
  onChange: (options: Option[]) => void;
}

interface CheckBoxItemProps {
  item: Option[]; values: string[]; itemButtonClickHandler: () => void
}
interface AllSelectButtomProps {
  label: string; allValue: string[]; allButtonClickHandler: () => void
}
const MultiCheck: React.FunctionComponent<Props> = (props): JSX.Element => {
  console.log(props);
  const { columns = 1, label = 'selecter all', onChange, options, values } = props;
  const allButtonClickHandler = (e: Event) => {
    const value = e.target.checked;
    if (value) {
      onChange(options)
    } else {
      onChange([])
    }

  }
  const itemButtonClickHandler = (e: Event, value: string) => {
    const getNewOption = (newValues: string[]) => {
      const newOption = options.filter(item => {
        return newValues.includes(item.value)
      })
      return newOption
    }

    if (values?.includes(value)) {
      const newValues = values.filter(item => {
        return item !== value
      })
      onChange(getNewOption(newValues))
    } else {
      const newValues = [...values, value]
      onChange(getNewOption(newValues))
    }
  }
  const allValue = options.length === values.length






  const getMultiWrapStyle = () => {
    const columnPercent = (100 / columns).toFixed(2)
    const row = Math.ceil((options.length + 1) / columns)
    const rowPercent = (100 / row).toFixed(2)
    return {
      'grid-template-rows': `repeat(${row}, ${rowPercent}%)`,
      'grid-template-columns': `repeat(${columns}, ${columnPercent}%)`
    }
  }





  return <div className='MultiCheck' style={getMultiWrapStyle()}>
    <AllSelectButtom {...{ label, allValue, allButtonClickHandler }} />
    {
      options.map((item, index) => <CheckBoxItem key={`${item}-${index}`} {...{ item, values, itemButtonClickHandler }} />)
    }
  </div>
}

const AllSelectButtom: React.FunctionComponent<AllSelectButtomProps> = (props): JSX.Element => {
  const { label, allValue, allButtonClickHandler } = props
  return <div className="item"><input type="checkbox" name={label} id={label} onChange={allButtonClickHandler} checked={allValue} />
    <label htmlFor={label}>{label}</label>
  </div >
}
const CheckBoxItem: React.FunctionComponent<CheckBoxItemProps> = (props): JSX.Element => {
  const { item, values, itemButtonClickHandler } = props
  return <div className="item"><input type="checkbox" onChange={(e) => { itemButtonClickHandler(e, item.value) }} name={item.label} id={item.label} checked={values?.includes(item.value)} />

    <label htmlFor={item.label}>{item.label}</label>
  </div>
}


export default MultiCheck;
